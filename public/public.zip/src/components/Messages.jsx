import React from "react";
import styled from "styled-components";

export default function Messages() {
  return <div>Messages</div>;
}

const Container = styled.div`
  height: 100%;
`;
